export const POSTHOG_MANAGED_HOSTS = ['https://app.posthog.com', 'https://eu.posthog.com']
